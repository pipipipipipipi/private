#!/bin/sh
################################################################
# pgxc_ha_add.sh
#
# Copyright (c) 2014 NIPPON TELEGRAPH AND TELEPHONE CORPORATION
# Version 2.0.0

### DEFINE
# crm_monで表示される判定項目
check1="Online:"
check2="master-Gtm"
check3="1000"
check4="PRI"
check5="HS:alone"
check6="HS:sync"
check_c1="coordinator1-status"
check_c2="coordinator2-status"
check_d1="datanode1-status"
check_d2="datanode2-status"
# タイムアウトカウント
timeout=30

### PARAMETER CHECK ###
if [ $# -eq 2 ];then
  case $1 in
  --add-group) group_num=$2 ;;
  esac
else
  echo "Usage : ${0##*/} --add-group GROUP_NUM "
  exit 1
fi

### FILE CHECK ###
ha_define_file="./pgxc_ha_define.conf"
if [ ! -f $ha_define_file ];then
  echo "### ERROR : NOT FOUND HA DEFINE FILE (file=$ha_define_file)"
  exit 1
fi
source $ha_define_file

# pgxc_install.shから抜粋
### FILE CHECK ###
readfile="./pgxc_readfile.sh"
if [ ! -f $readfile ];then
  echo "### ERROR : NOT FOUND INSTALL FILE (file=$readfile)"
  exit 1
fi
source $readfile

### FILE NAME ###
pgfile="postgresql.conf"
incfile="include.conf"
### Coordinator ###
cnt=`expr $cs + $group_num \* 2 - 2`
cnt_end=`expr $cnt + 1`
lan_cnt=`expr $group_num \* 2 - 1`
lan_cnt_end=`expr $group_num \* 2`
while [ $cnt -le $cnt_end ]
do
  xclan=`echo ${all[$cnt]} | awk -F'[,]' '{print $1}'`
  data=`echo ${all[$cnt]} | awk -F'[,]' '{print $5}'`
  conf=`echo ${all[$cnt]} | awk -F'[,]' '{print $13}'`
  file="$data/$pgfile"
  echo "*****  $xclan  *****"
# confファイルは、include.confという名前でコピーし、include文で取り込む
  if [ $conf ];then
    scp $conf ${data_slan[$lan_cnt]}:$data/$incfile > /dev/null || { echo "### ERROR : SET CONF ($file)"; exit 1; }
    ssh ${data_slan[$lan_cnt]} "echo \"include './$incfile'\" >> $file" || { echo "### ERROR : SET CONF ($file)"; exit 1; }
    scp $conf ${data_slan[$lan_cnt_end]}:$data/$incfile > /dev/null || { echo "### ERROR : SET CONF ($file)"; exit 1; }
    ssh ${data_slan[$lan_cnt_end]} "echo \"include './$incfile'\" >> $file" || { echo "### ERROR : SET CONF ($file)"; exit 1; }
  fi
  cnt=`expr $cnt + 1`
done
### Datanode ###
cnt=`expr $ds + $group_num \* 2 - 2`
cnt_end=`expr $cnt + 1`
lan_cnt=`expr $group_num \* 2 - 1`
lan_cnt_end=`expr $group_num \* 2`
while [ $cnt -le $cnt_end ]
do
  xclan=`echo ${all[$cnt]} | awk -F'[,]' '{print $1}'`
  data=`echo ${all[$cnt]} | awk -F'[,]' '{print $5}'`
  conf=`echo ${all[$cnt]} | awk -F'[,]' '{print $13}'`
  file="$data/$pgfile"
  echo "*****  $xclan  *****"
# confファイルは、include.confという名前でコピーし、include文で取り込む
  if [ $conf ];then
    scp $conf ${data_slan[$lan_cnt]}:$data/$incfile > /dev/null || { echo "### ERROR : SET CONF ($file)"; exit 1; }
    ssh ${data_slan[$lan_cnt]} "echo \"include './$incfile'\" >> $file" || { echo "### ERROR : SET CONF ($file)"; exit 1; }
    scp $conf ${data_slan[$lan_cnt_end]}:$data/$incfile > /dev/null || { echo "### ERROR : SET CONF ($file)"; exit 1; }
    ssh ${data_slan[$lan_cnt_end]} "echo \"include './$incfile'\" >> $file" || { echo "### ERROR : SET CONF ($file)"; exit 1; }
  fi
  cnt=`expr $cnt + 1`
done
# pgxc_install.shから抜粋ここまで

# pgxc_stop.shから抜粋
### Coordinator ###
echo "***** Coordinator **********"
cnt=`expr $cs + $group_num \* 2 - 2`
cnt_end=`expr $cnt + 1`
lan_cnt=`expr $group_num \* 2 - 1`
lan_cnt_end=`expr $group_num \* 2`
while [ $cnt -le $cnt_end ]
do
  slan=`echo ${all[$cnt]} | awk -F'[,]' '{print $2}'`
  data=`echo ${all[$cnt]} | awk -F'[,]' '{print $5}'`
  echo "*****  $slan  *****"
  newdata=`ssh $slan "echo $data"`
  ssh ${data_slan[$lan_cnt]} "pg_ctl stop -D $newdata" > /dev/null || { echo "### ERROR : STOP (Coordinator)"; }
  ssh ${data_slan[$lan_cnt_end]} "pg_ctl stop -D $newdata" > /dev/null || { echo "### ERROR : STOP (Coordinator)"; }
  cnt=`expr $cnt + 1`
done

### Datanode ###
echo "***** Datanode *************"
cnt=`expr $ds + $group_num \* 2 - 2`
cnt_end=`expr $cnt + 1`
lan_cnt=`expr $group_num \* 2 - 1`
lan_cnt_end=`expr $group_num \* 2`
while [ $cnt -le $cnt_end ]
do
  slan=`echo ${all[$cnt]} | awk -F'[,]' '{print $2}'`
  data=`echo ${all[$cnt]} | awk -F'[,]' '{print $5}'`
  echo "*****  $slan  *****"
  newdata=`ssh $slan "echo $data"`
  ssh ${data_slan[$lan_cnt]} "pg_ctl stop -D $newdata" > /dev/null || { echo "### ERROR : STOP (Datanode)"; }
  ssh ${data_slan[$lan_cnt_end]} "pg_ctl stop -D $newdata" > /dev/null || { echo "### ERROR : STOP (Datanode)"; }
  cnt=`expr $cnt + 1`
done

### GTM_proxy ###
echo "***** GTM_proxy ************"
cnt=`expr $ps + $group_num \* 2 - 2`
cnt_end=`expr $cnt + 1`
while [ $cnt -le $cnt_end ]
do
  slan=`echo ${all[$cnt]} | awk -F'[,]' '{print $2}'`
  data=`echo ${all[$cnt]} | awk -F'[,]' '{print $5}'`
  echo "*****  $slan  *****"
  newdata=`ssh $slan "echo $data"`
  ssh $slan "gtm_ctl stop -Z gtm_proxy -D $newdata" > /dev/null || { echo "### ERROR : STOP (GTM_proxy)"; }
  cnt=`expr $cnt + 1`
done

# pgxc_stop.shから抜粋ここまで

cnt=`expr $group_num \* 2 - 1`
cnt_end=`expr $group_num \* 2`
while [ $cnt -le $cnt_end ]
do
# (2) 各データサーバのPacemakerを起動する
  ssh -t ${data_slan[$cnt]} "sudo service heartbeat start > /dev/null" || { echo "### ERROR : PACEMAKER START (DATA:${data_slan[$cnt]})"; exit 1; }
  cnt=`expr $cnt + 1`
done

## DATA CRM LOAD
echo "### DATA CRM LOAD ###"
cnt=`expr $group_num \* 2 - 1`
sleep 30
# (7) データサーバ(各グループ内のA側)でリソース設定ファイルを読み込む
ssh -t ${data_slan[$cnt]} "sudo crm configure load update ${data_crm[$group_num]}" || { echo "### ERROR : CRM LOAD (DATA:${data_slan[$cnt]})"; }
sleep 5
ssh -t ${data_slan[$cnt]} "sudo crm configure load update ${data_crm[$group_num]} > /dev/null" || { echo "### ERROR : CRM LOAD (DATA:${data_slan[$cnt]})"; exit 1; }
sleep 60

## ARCHIVE SYNCHRONIZE
echo "### ARCHIVE SYNCHRONIZE ###"
cnt=`expr $group_num \* 2 - 1`
cnt_end=`expr $group_num \* 2`
while [ $cnt -le $cnt_end ]
do
  next=`expr $cnt + 1`
  ssh ${data_slan[$cnt]} "mkdir -p ${coord_arch[$cnt]}"
  ssh ${data_slan[$cnt]} "mkdir -p ${dn_arch[$cnt]}"
  ssh ${data_slan[$next]} "mkdir -p ${coord_arch[$cnt]}"
  ssh ${data_slan[$next]} "mkdir -p ${dn_arch[$cnt]}"
  ssh ${data_slan[$cnt]} "mkdir -p ${coord_arch[$next]}"
  ssh ${data_slan[$cnt]} "mkdir -p ${dn_arch[$next]}"
  ssh ${data_slan[$next]} "mkdir -p ${coord_arch[$next]}"
  ssh ${data_slan[$next]} "mkdir -p ${dn_arch[$next]}"
# (8) データサーバ(各グループ内のA側)で各コンポーネント(Coordinator1,Datanode1)の起動を確認したら、
#     それぞれアーカイブ同期を行う
  t_cnt=0
  while true
  do
    ssh -t ${data_slan[$cnt]} "sudo crm_mon -A -1 | grep $check_c1 | grep $check4" > /dev/null
    if [ $? -eq 0 ];then
      ssh -t ${data_slan[$cnt]} "sudo crm_mon -A -1 | grep $check_c1 | grep $check5" > /dev/null
      if [ $? -eq 0 ];then
        ssh -t ${data_slan[$cnt]} "sudo crm_mon -A -1 | grep $check_d1 | grep $check4" > /dev/null
        if [ $? -eq 0 ];then
          ssh -t ${data_slan[$cnt]} "sudo crm_mon -A -1 | grep $check_d1 | grep $check5" > /dev/null
          if [ $? -eq 0 ];then
            ssh ${data_slan[$cnt]} "scp -q ${coord_arch[$cnt]}/* ${data_slan[$next]}:${coord_arch[$cnt]}/. > /dev/null" || { echo "### ERROR : ARCHIVE SYNCHRONIZE (Coordinator1:${data_slan[$cnt]})"; exit 1; }
            ssh ${data_slan[$cnt]} "scp -q ${dn_arch[$cnt]}/* ${data_slan[$next]}:${dn_arch[$cnt]}/. > /dev/null" || { echo "### ERROR : ARCHIVE SYNCHRONIZE (Datanode1:${data_slan[$cnt]})"; exit 1; }
            break
          fi
        fi
      fi
    fi
    if [ $t_cnt -ge $timeout ];then
      echo "### ERROR : TIME OUT"
      exit 1
    fi
    t_cnt=`expr $t_cnt + 1`
    sleep 10
  done

# (9) データサーバ(各グループ内のB側)で各コンポーネント(Coordinator2,Datanode2)の起動を確認したら、
#     それぞれアーカイブ同期を行う
  t_cnt=0
  while true
  do
    ssh -t ${data_slan[$cnt]} "sudo crm_mon -A -1 | grep $check_c2 | grep $check4" > /dev/null
    if [ $? -eq 0 ];then
      ssh -t ${data_slan[$cnt]} "sudo crm_mon -A -1 | grep $check_c2 | grep $check5" > /dev/null
      if [ $? -eq 0 ];then
        ssh -t ${data_slan[$cnt]} "sudo crm_mon -A -1 | grep $check_d2 | grep $check4" > /dev/null
        if [ $? -eq 0 ];then
          ssh -t ${data_slan[$cnt]} "sudo crm_mon -A -1 | grep $check_d2 | grep $check5" > /dev/null
          if [ $? -eq 0 ];then
            ssh ${data_slan[$next]} "scp -q ${coord_arch[$next]}/* ${data_slan[$cnt]}:${coord_arch[$next]}/. > /dev/null" || { echo "### ERROR : ARCHIVE SYNCHRONIZE (Coordinator2:${data_slan[$next]})"; exit 1; }
            ssh ${data_slan[$next]} "scp -q ${dn_arch[$next]}/* ${data_slan[$cnt]}:${dn_arch[$next]}/. > /dev/null" || { echo "### ERROR : ARCHIVE SYNCHRONIZE (Datanode2:${data_slan[$next]})"; exit 1; }
            break
          fi
        fi
      fi
    fi
    if [ $t_cnt -ge $timeout ];then
      echo "### ERROR : TIME OUT"
      exit 1
    fi
    t_cnt=`expr $t_cnt + 1`
    sleep 10
  done
  cnt=`expr $cnt + 2`
done
echo "### FINISH ###"
